package com.example.cashbook;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class KasViewHolder extends RecyclerView.ViewHolder{
    TextView text_kas_id, text_tanggal,text_keterangan,text_total_kas,text_tipe_kas;
    ImageView logo_tipe_kas;

    public KasViewHolder(@NonNull View itemView) {
        super(itemView);
        text_kas_id    = itemView.findViewById(R.id.text_kas_id);
        text_tipe_kas = itemView.findViewById(R.id.text_tipe_kas);
        text_tanggal  = itemView.findViewById(R.id.text_tanggal);
        text_keterangan  = itemView.findViewById(R.id.text_keterangan);
        text_total_kas  = itemView.findViewById(R.id.text_total_kas);
        logo_tipe_kas = itemView.findViewById(R.id.logo_tipe_kas);
    }
}

package com.example.cashbook;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;

public class Pengaturan extends AppCompatActivity implements View.OnClickListener {

    Button simpan_password, kembali;
    EditText passwordBaru, passwordSekarang;
    DBHelper DB;

    TextView text_ganti_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pengaturan);
        DB = new DBHelper(this);

        text_ganti_password = findViewById(R.id.text_gantipassword);
        text_ganti_password.setPaintFlags(text_ganti_password.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        passwordBaru = findViewById(R.id.passwordBaru);
        passwordSekarang = findViewById(R.id.passwordSekarang);
        simpan_password = findViewById(R.id.simpan_password);
        kembali = findViewById(R.id.kembali);

        simpan_password.setOnClickListener(this);
        kembali.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()) {
            case R.id.simpan_password :

                break;


            case R.id.kembali :
                i = new Intent(this, HomeActivity.class);
                startActivity(i);
                break;
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}